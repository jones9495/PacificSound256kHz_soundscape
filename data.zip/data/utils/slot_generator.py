from datetime import datetime, timedelta, date, time
from models import Slot

def generate_slots(db, doctor_id, start: time, end: time, duration_minutes: int,
                   from_date: date, to_date: date):
    """
    Generate appointment slots for a doctor between from_date and to_date.
    Ensures no duplicates are created.
    """
    slots_created = []

    current_date = from_date
    while current_date <= to_date:
        current_time = datetime.combine(current_date, start)

        while current_time.time() < end:
            slot_start = current_time.time()
            slot_end = (current_time + timedelta(minutes=duration_minutes)).time()

            # Check if slot already exists
            existing = (
                db.query(Slot)
                .filter_by(doctor_id=doctor_id,
                           date=current_date,
                           start_time=slot_start,
                           end_time=slot_end)
                .first()
            )

            if not existing:
                new_slot = Slot(
                    doctor_id=doctor_id,
                    date=current_date,
                    start_time=slot_start,
                    end_time=slot_end,
                    is_booked=0
                )
                db.add(new_slot)
                slots_created.append(new_slot)

            current_time += timedelta(minutes=duration_minutes)

        current_date += timedelta(days=1)

    return slots_created
