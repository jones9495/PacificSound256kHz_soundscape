from sqlalchemy.orm import Session
from database import SessionLocal, engine, Base
from models import Doctor

def seed_doctors(n: int = 50):
    """
    Seeds N doctors into the database if they don't already exist.
    """
    db: Session = SessionLocal()

    try:
        existing_count = db.query(Doctor).count()
        if existing_count >= n:
            print(f"✅ Already have {existing_count} doctors.")
            return

        start = existing_count + 1
        for i in range(start, n + 1):
            name = f"Doctor {i}"
            specialization = "General Physician"

            # Check if doctor already exists
            existing = db.query(Doctor).filter_by(name=name).first()
            if not existing:
                doctor = Doctor(name=name, specialization=specialization)
                db.add(doctor)

        db.commit()
        print(f"✅ Seeded up to {n} doctors successfully.")
    except Exception as e:
        print("❌ Error seeding doctors:", e)
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    # Make sure DB tables exist
    Base.metadata.create_all(bind=engine)

    # Seed 50 doctors
    seed_doctors(50)
