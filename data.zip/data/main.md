###generate_slots_for_date : In the slot generating function we get the slot duration adn accordingly the slots are generated for each doctor.
Use cases
    1. Doctor can have seperate timings if they are practicing in hospitals . So how can we have day seperated by sessions.
    2.The appointments may not be available on all the days .