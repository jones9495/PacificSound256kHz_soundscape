from apscheduler.schedulers.background import BackgroundScheduler
from datetime import date, time, timedelta
from database import SessionLocal
from utils.slot_generator import generate_slots
from models import Doctor
import config

def create_slots_for_all_doctors():
    """Generate slots 14 days ahead for all doctors."""
    db = SessionLocal()
    try:
        doctors = db.query(Doctor).all()
        if not doctors:
            print("⚠️ No doctors found in DB")
            return

        today = date.today()
        horizon = today + timedelta(days=14)

        for doctor in doctors:
            slots = generate_slots(
                db=db,
                doctor_id=doctor.id,
                start=time(*config.WORKING_HOURS["start"]),
                end=time(*config.WORKING_HOURS["end"]),
                duration_minutes=config.WORKING_HOURS["duration_minutes"],
                from_date=today,
                to_date=horizon
            )
            print(f"✅ Created/ensured slots for Dr.{doctor.name}: {len(slots)} slots")

        db.commit()
    except Exception as e:
        print(f"❌ Slot generation failed: {e}")
    finally:
        db.close()

def start_scheduler():
    scheduler = BackgroundScheduler()
    scheduler.add_job(
        create_slots_for_all_doctors,
        "cron",
        hour=0, minute=5  # every midnight + 5 min
    )
    scheduler.start()
    print("✅ Scheduler started")
