COMPANY_NAME = "Your Clinic"

# Working hours for all doctors (can be customized per doctor later if needed)
WORKING_HOURS = {
    "start": (9, 0),   # 9:00 AM
    "end": (17, 0),    # 5:00 PM
    "duration_minutes": 30
}
