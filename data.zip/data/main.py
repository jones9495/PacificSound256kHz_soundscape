from fastapi import FastAPI, Form, Request, Depends
from twilio.rest import Client
import os, json
from datetime import datetime, timedelta
from sqlalchemy.orm import Session

import config
from database import get_db
from scheduler import start_scheduler
from models import Patient, State, Booking, Slot, Doctor

app = FastAPI()

# Twilio client
ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID")
AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN")
client = Client(ACCOUNT_SID, AUTH_TOKEN)

# Twilio Content SIDs
MENU_SID = "HXXXXXXXXXXXXXXXXXX"    
CANCEL_SID = "HXXXXXXXXXXXXXXXXXX"  

formatted_name = f"*{config.COMPANY_NAME}*"


@app.post("/whatsapp-webhook")
async def whatsapp_webhook(
    request: Request,
    From: str = Form(...),
    To: str = Form(...),
    Body: str = Form(None),
    ButtonResponse: str = Form(None),
    db: Session = Depends(get_db)
):
    user_message = Body.strip() if Body else ""
    button_id = None

    if ButtonResponse:
        try:
            btn_data = json.loads(ButtonResponse)
            button_id = btn_data.get("id")
        except:
            pass

    # ----------------------------
    # 1. Greeting → Ask for name
    # ----------------------------
    if user_message.lower() in ["hi", "hello", "hey"]:
        state = db.query(State).filter_by(phone=From).first()
        if not state:
            state = State(phone=From, state="awaiting_name")
            db.add(state)
        else:
            state.state = "awaiting_name"
        db.commit()

        client.messages.create(
            from_=To,
            to=From,
            body=f"👋 Hi! Thanks for reaching {formatted_name}. \n\nPlease provide your first name"
        )
        return {"status": "asked name"}

    # ----------------------------
    # 2. Save Name → Show Menu
    # ----------------------------
    state = db.query(State).filter_by(phone=From).first()
    if state and state.state == "awaiting_name" and not button_id:
        name = user_message
        patient = db.query(Patient).filter_by(phone=From).first()
        if not patient:
            patient = Patient(phone=From, name=name)
            db.add(patient)
        else:
            patient.name = name
        state.state = "menu_shown"
        db.commit()

        client.messages.create(from_=To, to=From, content_sid=MENU_SID)
        return {"status": f"name saved: {name}, menu sent"}

    # ----------------------------
    # 3. Main Menu → Choose Doctor
    # ----------------------------
    if button_id == "schedule":
        doctors = db.query(Doctor).all()
        if not doctors:
            client.messages.create(from_=To, to=From, body="❌ No doctors are available right now.")
            return {"status": "no doctors"}

        actions = [
            {"type": "quick_reply", "title": f"Dr. {d.name}", "id": f"doctor_{d.id}"}
            for d in doctors[:10]
        ]
        payload = {
            "from": To,
            "to": From,
            "interactive_data": {
                "type": "quick_reply",
                "body": "👨‍⚕️ Please choose your doctor:",
                "actions": actions
            }
        }
        client.messages.create(**payload)
        return {"status": "doctor options sent"}

    # ----------------------------
    # 4. After Doctor Selected → Show Slots
    # ----------------------------
    if button_id and button_id.startswith("doctor_"):
        doctor_id = int(button_id.replace("doctor_", ""))
        today = datetime.now().date()
        horizon = today + timedelta(days=14)

        slots = (
            db.query(Slot)
              .filter(Slot.doctor_id == doctor_id,
                      Slot.date >= today,
                      Slot.date <= horizon,
                      Slot.is_booked == 0)
              .order_by(Slot.date, Slot.start_time)
              .all()
        )

        if not slots:
            client.messages.create(from_=To, to=From,
                body="❌ Sorry, no slots are available in the next 14 days for this doctor.")
            return {"status": "no slots"}

        slot_choices = slots[:10]
        actions = [
            {"type": "quick_reply",
             "title": f"{s.date.strftime('%b %d')} - {s.start_time.strftime('%I:%M %p')}",
             "id": f"slot_{s.id}"}
            for s in slot_choices
        ]
        payload = {
            "from": To,
            "to": From,
            "interactive_data": {
                "type": "quick_reply",
                "body": "⏰ Please select an available slot:",
                "actions": actions
            }
        }
        client.messages.create(**payload)
        return {"status": "slot options sent"}

    # ----------------------------
    # 5. Slot Booking
    # ----------------------------
    if button_id and button_id.startswith("slot_"):
        slot_id = int(button_id.replace("slot_", ""))
        slot = db.query(Slot).filter_by(id=slot_id, is_booked=0).first()

        if slot:
            patient = db.query(Patient).filter_by(phone=From).first()
            if patient:
                booking = Booking(patient_id=patient.id, slot_id=slot.id)
                db.add(booking)
                slot.is_booked = 1
                db.commit()

                client.messages.create(
                    from_=To,
                    to=From,
                    body=f"✅ {patient.name}, your booking is confirmed with Dr.{slot.doctor.name} at {slot.start_time.strftime('%I:%M %p')} on {slot.date.strftime('%b %d')}!"
                )
                return {"status": "booking confirmed"}
        else:
            client.messages.create(from_=To, to=From,
                body="❌ That slot is no longer available. Please choose another.")
            return {"status": "slot unavailable"}

    # ----------------------------
    # Fallback
    # ----------------------------
    client.messages.create(from_=To, to=From,
        body="Sorry, I didn’t understand. Please type 'hi' to start again.")
    return {"status": "fallback"}


@app.on_event("startup")
def start_background_tasks():
    start_scheduler()
